<?php
include("configFile.php");
$data = file_get_contents('php://input');
$json_data = json_decode($data , true);

// if ($_SERVER['REQUEST_METHOD'] === 'POST') 
// {
//code to process data
if ($data == "")
{
    $response = array('status' => false, 'message' => 'Invalid Values');    
}
else
{
    $ID=$json_data['id'];
    $LayoutID=$json_data['layoutId'];
    $NumberOfTable=$json_data['numberOfTable'];
    $TableCapacity=$json_data['tableCapacity'];

    // $ID='14';
    // $LayoutID='31';
    // $NumberOfTable='2';
    // $TableCapacity='5';

    $conn = new mysqli($servername, $username, $password,$db_name);
    // Check connection
    if (!$conn) {
        $response = array('status' => false, 'message' => 'Unable to connect server!');
        echo json_encode($response);
        die("Connection failed: " . mysqli_connect_error());
    }
    
    $sql = "UPDATE tbl_floor SET number_of_table='".$NumberOfTable."' WHERE id='".$ID."'";
    
    if (mysqli_query($conn, $sql)) {
        $last_id = mysqli_insert_id($conn);
        //echo "New record created successfully. Last inserted ID is: " . $last_id;
        $table_sql="INSERT INTO tbl_tables (floor_id,table_capacity) VALUES ('".$ID."','".$TableCapacity."')"; 
        
        if (mysqli_query($conn, $table_sql)) {
            $tablelast_id = mysqli_insert_id($conn);
            //echo "New record created successfully. Last inserted ID is: " . $last_id;
            $response = array('status' => true, 'message' => 'success');
  
        } else {
            $response = array('status' => false, 'message' => 'Unable Add Layout!');
        }  

    } else {
        $response = array('status' => false, 'message' => 'Unable Add Layout!');
    }
    
    mysqli_close($conn);
 }

echo json_encode($response);

?>