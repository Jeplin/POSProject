<?php

include('configFile.php');

$data = file_get_contents('php://input');
$json_data = json_decode($data , true);

// Create connection
$conn = new mysqli($servername, $username, $password,$db_name);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$mainData_arr=array();
if ($data == "")
{
    $response = array('status' => false, 'message' => 'Invalid Values');    
}
else
{
        $FloorNo=$json_data["floorNo"];
        $TableNo=$json_data["tableNo"];

         //$FloorNo=1;
         //$TableNo=1;

        // Layout Data Table 
        $sqlTable="SELECT a.id,a.floor_no,a.table_no,a.customer_name,a.taken_by,a.modified_date,b.order_status FROM tbl_tableorders as a LEFT JOIN tbl_order_status as b ON a.order_status=b.id WHERE a.floor_no='$FloorNo' AND a.table_no='$TableNo' AND a.order_status='1'";
        $tableResult=$conn->query($sqlTable);

        
        $tableOrder_Arr=array();
        if($tableResult->num_rows > 0){
            while($row=$tableResult->fetch_assoc()){
                //print_r($row);
                //array_push($tableOrder_Arr,$row);
                $table_id=$row["id"];
                $tableOrder_Data=$row;

                $sqlOrder="SELECT * FROM tbl_allorders WHERE tableorder_id='$table_id'";
            
                $OrderResult = $conn->query($sqlOrder);
            
                $main_order_Array=array();
                if ($OrderResult->num_rows > 0) {
                    // output data of each row
                    while($row1 = $OrderResult->fetch_assoc()) {            
                        array_push($main_order_Array,$row1);
                    }
                }

                $temOrdered=array(
                    'taken_by'=>$row['taken_by'],
                    'orders'=>$main_order_Array
                );

                array_push($tableOrder_Arr,$temOrdered);

            }

            //echo "<pre>";
            //print_r($tableOrder_Arr);
            //$sample=array();
            $main_Layout_Data=array(
                "id" => $tableOrder_Data['id'],
                "floorNo" => $tableOrder_Data['floor_no'],
                "tableNo" => $tableOrder_Data['table_no'],
                "customerName"=>$tableOrder_Data['customer_name'],
                "orderStatus" => $tableOrder_Data['order_status'],
                "allorders" => $tableOrder_Arr,
                "modified_date"=>$tableOrder_Data['modified_date']
                
            );
            array_push($mainData_arr,$main_Layout_Data);
            //echo "<pre>";
            // echo "Main Layout Data";
            //print_r($mainData_arr);
            // echo "<br/>";
            // echo "END";
            //mysqli_close($conn);
            
            //echo json_encode($mainData_arr);
            //echo "[]";
            

        }
}
mysqli_close($conn);
echo json_encode($mainData_arr);


?>
