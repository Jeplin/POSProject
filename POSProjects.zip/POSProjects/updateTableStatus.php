<?php
include("configFile.php");
$data = file_get_contents('php://input');
$json_data = json_decode($data , true);

// if ($_SERVER['REQUEST_METHOD'] === 'POST') 
// {
//code to process data
if ($data == "")
{
    $response = array('status' => false, 'message' => 'Invalid Values');    
}
else
{
    //  $ID=$json_data['id'];
    //  $LayoutID=$json_data['floorId'];
    //  $TableStatus=$json_data['tableStatus'];
    //$ID='50';
    //$LayoutID=$json_data['floorId'];
    //$TableStatus='1';
    $TableId=$json_data['tableId'];
    $OrderedId=$json_data['orderedId'];

    $conn = new mysqli($servername, $username, $password,$db_name);
    // Check connection
    if (!$conn) {
        $response = array('status' => false, 'message' => 'Unable to connect server!');
        echo json_encode($response);
        die("Connection failed: " . mysqli_connect_error());
    }
    
    $sql = "UPDATE tbl_tables SET table_status='1' WHERE id='".$TableId."'";
    
    if (mysqli_query($conn, $sql)) {
        $orderSQL="UPDATE tbl_tableorders SET order_status='0' WHERE id='".$OrderedId."'";
        if(mysqli_query($conn,$orderSQL)){
            $response = array('status' => true, 'message' => 'success');
        }
        else{
            $response = array('status' => false, 'message' => 'Unable Add Layout!');
        }
        //echo "New record created successfully. Last inserted ID is: " . $last_id;
        
    } else {
        $response = array('status' => false, 'message' => 'Unable Add Layout!');
    }
    
    mysqli_close($conn);
  }

echo json_encode($response);

?>