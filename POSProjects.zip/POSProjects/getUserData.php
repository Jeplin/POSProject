<?php

include('configFile.php');

// Create connection
$conn = new mysqli($servername, $username, $password,$db_name);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$USER_ID=1;
 
$sqlUser="SELECT a.*,b.type FROM tbl_users as a LEFT JOIN tbl_usertype as b  ON a.user_type_id=b.id WHERE a.id='$USER_ID'";
$userResult=$conn->query($sqlUser);

// echo "Data ";
 //echo "<pre>";
$mainData_arr=array();

$user_Arr=array();
if($userResult->num_rows > 0){
    while($row=$userResult->fetch_assoc()){
        array_push($user_Arr,$row);
    }

    $user_Data=$user_Arr[0];
    $user_id=$user_Data["id"];
    //Floor Data fetch 
    $sqlUserDetail="SELECT * FROM tbl_userdetail WHERE user_id='$user_id'";
    
    $detailResult = $conn->query($sqlUserDetail);
    
    $Detail_Array=array();
    if ($detailResult->num_rows > 0) {
        // output data of each row
        while($row1 = $detailResult->fetch_assoc()) {
            
            array_push($Detail_Array,$row1);
        }
        //print_r($Detail_Array);

        $sqlCurDetail="SELECT * FROM tbl_current_address WHERE user_id='$user_id'";
        $curDetailResult=$conn->query($sqlCurDetail);
        $Current_Arr=array();
        if($curDetailResult->num_rows>0){
            while($row2=$curDetailResult->fetch_assoc()){
                array_push($Current_Arr,$row2);
            }
            //print_r($Current_Arr);
        }

        $sqlPerDetail="SELECT * FROM tbl_permanent_address WHERE user_id='$user_id'";
        $perDetailResult=$conn->query($sqlPerDetail);
        $Permanent_arr=array();
        if($perDetailResult->num_rows>0){
            while($row2=$perDetailResult->fetch_assoc()){
                array_push($Permanent_arr,$row2);
            }
            //print_r($Permanent_arr);
        }

        $Full_detail=array(
            'detail'=>$Detail_Array[0],
            'currentAddress'=>$Current_Arr[0],
            'permanentAddress'=>$Permanent_arr[0]
        );
    }

    $allData=array(
        'id'=>$user_Data['id'],
        'userTypeId'=>$user_Data['user_type_id'],
        'userType'=>$user_Data['type'],
        'firstName'=>$user_Data['fname'],
        'lastName'=>$user_Data['lname'],
        'username'=>$user_Data['username'],
        'password'=>$user_Data['password'],
        'joiningDate'=>$user_Data['joining'],
        'details'=>$Full_detail,
        'modified_date'=>$user_Data['modified_date']
    );
    
    array_push($mainData_arr,$allData);

    // array_push($mainData_arr,$main_Layout_Data);
    //echo "<pre>";
    // echo "Main Layout Data";
    //print_r($mainData_arr);
    // echo "<br/>";
    
    

}
mysqli_close($conn);
echo json_encode($mainData_arr);


?>