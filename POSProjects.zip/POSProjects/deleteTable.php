<?php
include("configFile.php");
$data = file_get_contents('php://input');
$json_data = json_decode($data , true);

// if ($_SERVER['REQUEST_METHOD'] === 'POST') 
// {
//code to process data
if ($data == "")
{
    $response = array('status' => false, 'message' => 'Invalid Values');    
}
else
{
    $ID=$json_data['id'];

    $conn = new mysqli($servername, $username, $password,$db_name);
    // Check connection
    if (!$conn) {
        $response = array('status' => false, 'message' => 'Unable to connect server!');
        echo json_encode($response);
        die("Connection failed: " . mysqli_connect_error());
    }
    
    $sql = "DELETE FROM tbl_tables WHERE id='".$ID."'";
    
    if (mysqli_query($conn, $sql)) {
        //$last_id = mysqli_insert_id($conn);
        //echo "New record created successfully. Last inserted ID is: " . $last_id;
        $response = array('status' => true, 'message' => 'success');
    } else {
        $response = array('status' => false, 'message' => 'Unable Add Layout!');
    }
    
    mysqli_close($conn);
 }

echo json_encode($response);

?>