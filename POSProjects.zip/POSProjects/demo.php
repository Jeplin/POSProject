<?php

include('configFile.php');

// Create connection
$conn = new mysqli($servername, $username, $password,$db_name);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Layout Data Table 
$sqlLayout="SELECT * FROM tbl_layout";
$layoutResult=$conn->query($sqlLayout);

$layout_Arr=array();
if($layoutResult->num_rows > 0){
    while($row=$layoutResult->fetch_assoc()){
        array_push($layout_Arr,$row);
    }
}

echo json_encode($layout_Arr);
mysqli_close($conn);

?>