<?php

include('configFile.php');

// Create connection
$conn = new mysqli($servername, $username, $password,$db_name);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Layout Data Table 
$sqlLayout="SELECT a.id,b.category,a.item_name,a.item_price FROM tbl_menucard as a LEFT JOIN tbl_menu_category as b ON a.category_id=b.id";

$layoutResult=$conn->query($sqlLayout);

$layout_Arr=array();
if($layoutResult->num_rows > 0){
    while($row=$layoutResult->fetch_assoc()){
        array_push($layout_Arr,$row);
    }
}
mysqli_close($conn);
echo json_encode($layout_Arr);


?>
