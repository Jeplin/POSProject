<?php

include('configFile.php');

$data = file_get_contents('php://input');
$json_data = json_decode($data , true);

// Create connection
$conn = new mysqli($servername, $username, $password,$db_name);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$mainData_arr=array();
if ($data == "")
{
    $response = array('status' => false, 'message' => 'Invalid Values');    
}
else
{
         $Username=$json_data["username"];
         $Password=$json_data["password"];

         //$Username='jeplin';
         //$Password='123456';

        // Layout Data Table 
        $sqlTable="SELECT * FROM tbl_users WHERE username='$Username' AND password='$Password'";
        $tableResult=$conn->query($sqlTable);

        
        $tableOrder_Arr=array();
        if($tableResult->num_rows > 0){
            while($row=$tableResult->fetch_assoc()){
                //print_r($row);
                array_push($mainData_arr,$row);
            }
            //echo "<pre>";
            // echo "Main Layout Data";
            //print_r($mainData_arr);         

        }
        else{

        }
}
mysqli_close($conn);
echo json_encode($mainData_arr);


?>
