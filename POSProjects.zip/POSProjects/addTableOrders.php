<?php
include("configFile.php");

$data = file_get_contents('php://input');
$json_data = json_decode($data , true);

// if ($_SERVER['REQUEST_METHOD'] === 'POST') 
// {
//code to process data
if ($data == "")
{
    $response = array('status' => false, 'message' => 'Invalid Values');    
}
else
 {

    $TableID=$json_data["tableId"];
    $FloorNo=$json_data['floorNo'];
    $TableNo=$json_data['tableNo'];
    $Orders=$json_data['order'];
    $CustomerName=$json_data['customerName'];
    $UserId=$json_data['userId'];
   

    //var temorder=[{item:""}}

    // $TableID=23;
    // $FloorNo=10;
    // $TableNo=12;
    // $Orders=[];
    // $CustomerName="Jack";
    

    // $Orders=[{itemName: "Biryani", itemPrice: "100", quant: 1},
    // {itemName: "Pizza", itemPrice: "200", quant: 1},
    // {itemName: "Burger", itemPrice: "20", quant: 1}];

    $conn = new mysqli($servername, $username, $password,$db_name);
    // Check connection
    if (!$conn) {
        $response = array('status' => false, 'message' => 'Unable to connect server!');
        //echo json_encode($response);
        die("Connection failed: " . mysqli_connect_error());
    }
    

    $sqlTableOrder="SELECT id FROM tbl_tableorders WHERE floor_no='$FloorNo' AND table_no='$TableNo' AND customer_name='$CustomerName'AND taken_by='$UserId' AND order_status='1'";
    
    $TableOrderResult = $conn->query($sqlTableOrder);
    
    if ($TableOrderResult->num_rows > 0) {
        while($row1 = $TableOrderResult->fetch_assoc()) {
            $temTable_id=$row1["id"];
//echo "Table floor row match";
            

           foreach($Orders as $order){
                 $ItemName=$order["itemName"];
                 $ItemQuant=$order["quant"];
                 $TotPrice=$order["itemPrice"];
                 $ItemPrice=$TotPrice/$ItemQuant;
                // $ItemName="Burer23";
                // $ItemQuant=1;
                // $TotPrice=200;
                // $ItemPrice=200;

                $table_sql="INSERT INTO tbl_allorders (tableorder_id,item,quant,price,tot_price) VALUES ('".$temTable_id."','".$ItemName."','".$ItemQuant."','".$ItemPrice."','".$TotPrice."')"; 
               
                if (mysqli_query($conn, $table_sql)) { 

                    $response = array('status' => true, 'message' => 'success');
    
                } else {
                    $response = array('status' => false, 'message' => 'Unable Add Order!');
                }  
            }
            
        }
        
    }
    else{
        //echo "No Data";
       $sql = "INSERT INTO tbl_tableorders (floor_no,table_no,customer_name,taken_by,order_status) VALUES('".$FloorNo."','".$TableNo."','".$CustomerName."','".$UserId."','1')";

        if (mysqli_query($conn, $sql)) {
            $last_id = mysqli_insert_id($conn);
            //echo "New record created successfully. Last inserted ID is: " . $last_id;
            //echo "Insert Called ";
            //addOrders($last_id);
            foreach($Orders as $order){
                $ItemName=$order["itemName"];
                $ItemQuant=$order["quant"];
                $TotPrice=$order["itemPrice"];
                $ItemPrice=$TotPrice/$ItemQuant;
                // $ItemName="Burer";
                // $ItemQuant=1;
                // $TotPrice=200;
                // $ItemPrice=200;

                $table_sql="INSERT INTO tbl_allorders (tableorder_id,item,quant,price,tot_price) VALUES ('".$last_id."','".$ItemName."','".$ItemQuant."','".$ItemPrice."','".$TotPrice."')"; 
                if (mysqli_query($conn, $table_sql)) { 

                    $tableStatussql = "UPDATE tbl_tables SET table_status='3' WHERE id='".$TableID."'";

                    if (mysqli_query($conn, $tableStatussql)) { 
    
                        $response = array('status' => true, 'message' => 'success');
                               
                    } else {
                        $response = array('status' => false, 'message' => 'Unable Add Order!');
                    }  
                           
                } else {
                    $response = array('status' => false, 'message' => 'Unable Add Order!');
                }  
             }

        } else {
            $response = array('status' => false, 'message' => 'Unable Add Order1!');
        }
    
    }
    
    mysqli_close($conn);
 }

echo json_encode($response);

?>