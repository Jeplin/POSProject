<?php

include('configFile.php');

$data = file_get_contents('php://input');
$json_data = json_decode($data , true);

// Create connection
$conn = new mysqli($servername, $username, $password,$db_name);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$mainData_arr=array();
if ($data == "")
{
    $response = array('status' => false, 'message' => 'Invalid Values');    
}
else
{

    $USER_ID=$json_data['userId'];
    // Layout Data Table 
    $sqlUser="SELECT * FROM tbl_user_attendence WHERE user_id='$USER_ID' ORDER BY id DESC";
    $userResult=$conn->query($sqlUser);

    // echo "Data ";
    // echo "<pre>";

    

    $user_Arr=array();
    if($userResult->num_rows > 0){
        while($row=$userResult->fetch_assoc()){
            array_push($user_Arr,$row);
        }
        array_push($mainData_arr,$user_Arr);
        //echo "<pre>";
        // echo "Main Layout Data";
        //print_r($mainData_arr);
        // echo "<br/>";
        // echo "END";
        //mysqli_close($conn);
        
        //echo json_encode($mainData_arr);
        //echo "[]";
        

    }
    else{
        $response = array('status' => false, 'message' => 'Invalid Values');
    }
}
mysqli_close($conn);
echo json_encode($mainData_arr);
?>