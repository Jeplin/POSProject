<?php
include("configFile.php");
$data = file_get_contents('php://input');
$json_data = json_decode($data , true);

//code to process data
$conn = new mysqli($servername, $username, $password,$db_name);
    // Check connection
if (!$conn) {
        $response = array('status' => false, 'message' => 'Unable to connect server!');
        echo json_encode($response);
        die("Connection failed: " . mysqli_connect_error());
}
if ($data == "")
{
    $response = array('status' => false, 'message' => 'Invalid Values');    
}
else
{
     $UserId=$json_data['userId'];
     $InTime=$json_data['inTime'];
     $OutTime=$json_data['outTime'];
    // $UserId=2;
    // $InTime='2018-02-10 12:21:11';
    // $OutTime='';

    if($InTime!=''){
        $sql="INSERT INTO tbl_user_attendence (user_id,in_time,out_time) VALUES ('".$UserId."','".$InTime."','".$OutTime."')"; 
    
        if (mysqli_query($conn, $sql)) {
            $last_id = mysqli_insert_id($conn);
            //echo "New record created successfully. Last inserted ID is: " . $last_id;
            $response = array('status' => 'success', 'message' => $last_id); 
    
        } else {
            $response = array('status' => false, 'message' => 'Unable Add Layout!');
        }
    }
    else {
        $ID=$json_data['att_id'];

        $sql = "UPDATE tbl_user_attendence SET out_time='$OutTime' WHERE id='".$ID."'";
    
        if (mysqli_query($conn, $sql)) {
            
            $response = array('status' => true, 'message' => 'success');
            
            //echo "New record created successfully. Last inserted ID is: " . $last_id;
            
        } else {
            $response = array('status' => false, 'message' => 'Unable Add Layout!');
        }
    }

    
    
    mysqli_close($conn);
 }

echo json_encode($response);

?>