<?php
include("configFile.php");
$data = file_get_contents('php://input');
$json_data = json_decode($data , true);

// if ($_SERVER['REQUEST_METHOD'] === 'POST') 
// {
$conn = new mysqli($servername, $username, $password,$db_name);
    // Check connection
if (!$conn) {
    $response = array('status' => false, 'message' => 'Unable to connect server!');
    echo json_encode($response);
    die();
}
//code to process data
if ($data == "")
{
    $response = array('status' => false, 'message' => 'Invalid Values');    
}
else
{
    $UserID=$json_data['id'];
    $Email=$json_data['email'];
    $Contact=$json_data['contact'];
    $FatherName=$json_data['fatherName'];
    $MotherName=$json_data['motherName'];
    $FamilyContact=$json_data['familyContact'];

    $CurAddr1=$json_data['curAddr1'];
    $CurAddr2=$json_data['curAddr2'];
    $CurCity=$json_data['curCity'];
    $CurState=$json_data['curState'];
    $CurCountry=$json_data['curCountry'];
    $CurPin=$json_data['curPin'];

    $perAddr1=$json_data['perAddr1'];
    $perAddr2=$json_data['perAddr2'];
    $perCity=$json_data['perCity'];
    $perState=$json_data['perState'];
    $perCountry=$json_data['perCountry'];
    $perPin=$json_data['perPin'];

    // $UserID='2';
    // $Email="jack@jone";
    // $Contact="NA";
    // $FatherName="NA";
    // $MotherName="NA";
    // $FamilyContact="NA";

    // $CurAddr1="NA";
    // $CurAddr2="NA";
    // $CurCity="NA";
    // $CurState="NA";
    // $CurCountry="NA";
    // $CurPin="NA";

    // $PerAddr1="NA";
    // $PerAddr2="NA";
    // $PerCity="NA";
    // $PerState="NA";
    // $PerCountry="NA";
    // $PerPin="NA";

    
    // $sql = "UPDATE tbl_userdetail SET table_capacity='".$TableCapacity."' WHERE id='".$ID."'";
    $sql = "UPDATE tbl_userdetail SET email='".$Email."',contact='".$Contact."',fathername='".$FatherName."',mothername='".$MotherName."',familycontact='".$FamilyContact."' WHERE user_id='".$UserID."'";
    
    if (mysqli_query($conn, $sql)) {
        $last_id = mysqli_insert_id($conn);

        $sqlCur="UPDATE tbl_current_address SET address_one='".$CurAddr1."',address_two='".$CurAddr2."',city='".$CurCity."',state='".$CurState."',country='".$CurCountry."',pincode='".$CurPin."' WHERE user_id='".$UserID."'";
        if (mysqli_query($conn, $sqlCur)) {
            $response = array('status' => true, 'message' => 'success');
        }
        else{
            $response = array('status' => false, 'message' => 'Unable Add Layout!');
        }

        $sqlPer="UPDATE tbl_permanent_address SET address_one='".$PerAddr1."',address_two='".$PerAddr2."',city='".$PerCity."',state='".$PerState."',country='".$PerCountry."',pincode='".$PerPin."' WHERE user_id='".$UserID."'";
        if (mysqli_query($conn, $sqlPer)) {
            $response = array('status' => true, 'message' => 'success');
        }
        else{
            $response = array('status' => false, 'message' => 'Unable Add Layout!');
        }
        //echo "New record created successfully. Last inserted ID is: " . $last_id;
        
    } else {
        $response = array('status' => false, 'message' => 'Unable Add Layout!');
    }
    
    mysqli_close($conn);
 }

echo json_encode($response);

?>