<?php
include("configFile.php");
$data = file_get_contents('php://input');
$json_data = json_decode($data , true);
if ($_SERVER['REQUEST_METHOD'] === 'POST') 
{
//code to process data
if ($data == "")
{
    $response = array('status' => false, 'message' => 'Invalid Values','id'=>'');    
}
else
{
    $STATUS=$json_data['status'];
    $ADMINID=$json_data['adminId'];
    $LayoutTitle=$json_data['layoutTitle'];
    $FloorNumber=$json_data['numberOfFloor'];

    $conn = new mysqli($servername, $username, $password,$db_name);
    // Check connection
    if (!$conn) {
        $response = array('status' => false, 'message' => 'Unable to connect server!','id'=>'');
        echo json_encode($response);
        die("Connection failed: " . mysqli_connect_error());
    }
    
    $sql = "INSERT INTO tbl_layout (status, admin_id, number_of_floor,layout_title)
    VALUES ('".$STATUS."', '".$ADMINID."','".$FloorNumber."','".$LayoutTitle."')";
    
    if (mysqli_query($conn, $sql)) {
        $last_id = mysqli_insert_id($conn);
        //echo "New record created successfully. Last inserted ID is: " . $last_id;
        while($FloorNumber>0){
            $floor_sql="INSERT INTO tbl_floor (layout_id,number_of_table) VALUES ('".$last_id."',0)";
            
            if(mysqli_query($conn,$floor_sql)){
                $response = array('status' => true, 'message' => 'success','id'=>$last_id);
            }
            else{
                $response = array('status' => false, 'message' => 'Unable Add Layout!','id'=>'');
            }
            $FloorNumber=$FloorNumber-1;
        }    
    } else {
        $response = array('status' => false, 'message' => 'Unable Add Layout!','id'=>'');
    }
    
    mysqli_close($conn);
 }

echo json_encode($response);
}
?>