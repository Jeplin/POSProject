<?php

include('configFile.php');

// Create connection
$conn = new mysqli($servername, $username, $password,$db_name);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Layout Data Table 
$sqlLayout="SELECT * FROM tbl_layout";
$layoutResult=$conn->query($sqlLayout);

$layout_Arr=array();
if($layoutResult->num_rows > 0){
    while($row=$layoutResult->fetch_assoc()){
        array_push($layout_Arr,$row);
    }
}
$layout_Data=$layout_Arr[0];
$layout_id=$layout_Data["id"];
//Floor Data fetch 
$sqlFloor="SELECT * FROM tbl_floor WHERE layout_id='$layout_id'";

$FloorResult = $conn->query($sqlFloor);

$main_Floor_Array=array();
if ($FloorResult->num_rows > 0) {
    // output data of each row
    while($row1 = $FloorResult->fetch_assoc()) {
        $tempfloor_id=$row1["id"];

        $sqlTable="SELECT * FROM tbl_tables WHERE floor_id='$tempfloor_id'";
        $TableResult=$conn->query($sqlTable);
        $temp_arr=array();
        if($TableResult->num_rows > 0){
            while($row2 = $TableResult->fetch_assoc()){
                array_push($temp_arr,$row2);
            }
        }
        $product_item=array(
            "id" => $row1['id'],
            "layout_id" => $row1['layout_id'],
            "number_of_table" => $row1['number_of_table'],
            "tables" => $temp_arr,
            "modified_date" => $row1['modified_date']
        );
        
        array_push($main_Floor_Array,$product_item);
    }
}
$main_Layout_Data=array(
    "id" => $layout_Data['id'],
    "admin_id" => $layout_Data['admin_id'],
    "number_of_floor" => $layout_Data['number_of_floor'],
    "floors" => $main_Floor_Array,
    "modified_date" => $layout_Data['modified_date']
);
// echo "<pre>";
// echo "Main Layout Data";
// print_r($main_Layout_Data);
// echo "<br/>";
// echo "END";
mysqli_close($conn);
echo json_encode($main_Layout_Data);


?>
